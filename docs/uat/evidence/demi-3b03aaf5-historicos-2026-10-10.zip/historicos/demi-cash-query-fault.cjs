const fs = require('node:fs');
const originalFetch = globalThis.fetch;
globalThis.fetch = async function(input, init) {
  const rawUrl = typeof input === 'string' ? input : input instanceof URL ? input.href : input.url;
  const url = new URL(rawUrl);
  if (fs.existsSync('/workspace/work/demi-cash-query-fault.on') &&
      url.hostname === 'hedouonyhynuvwbckdlg.supabase.co' &&
      url.pathname === '/rest/v1/demi_cash_purchases' &&
      url.searchParams.get('studio_id') === 'eq.29af8ae6-1c55-497d-b53c-d6d7b6fc828d') {
    console.log('UAT C09: injected cash query failure for the existing isolated run');
    return new Response(JSON.stringify({code:'UAT_C09',message:'Injected query failure'}),{status:503,headers:{'content-type':'application/json'}});
  }
  return originalFetch.call(this,input,init);
};
