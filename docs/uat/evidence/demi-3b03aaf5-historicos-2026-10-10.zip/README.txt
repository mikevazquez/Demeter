Evidencias UAT Demi, PR #265
Ejecucion recuperada: 3b03aaf5-b014-4277-bc69-cef7aa2ba271.
No se recrearon escenarios. Produccion no modificada.

Descargas iniciales, intermedias y finales, capturas reales del navegador e imagenes simuladas de comprobante. Las imagenes no representan pagos reales; se usaron solo en el estudio ficticio de Sandbox. Se conserva el rechazo de la imagen marcada sin valor.

Algunas descargas intermedias precedieron al fin de una respuesta; deben leerse en orden con demi-C03-confirmation-retry-final.json, la matriz de cierre y los historicos, no como aprobacion aislada. Se conservan tambien los errores de selector para trazabilidad.

C09: pagina real de Next.js, local, conectada a Sandbox; inyeccion 503 limitada al estudio UAT, retirada al terminar. No se modificaron permisos para provocar el fallo.

Se excluyen credenciales, cookies, configuracion de navegador y enlaces temporales de acceso. manifest.json contiene hashes SHA-256 de los originales.
